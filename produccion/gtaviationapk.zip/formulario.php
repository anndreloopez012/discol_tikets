<?php 
require 'main_app/main.php';

if( isset($_REQUEST['logout']) ){
    unset($_SESSION['usuario']);
    header('Location:index.php');
}


if ( isset($_GET["validaciones"]) && !empty($_GET["validaciones"]) ){
    
    $connect = conectar();
    
    if ( $_GET["validaciones"] == "recibo_entrega" ){
        
        $intRecibo = isset($_GET["recibo"]) ? intval($_GET["recibo"]) : 0;
        
        $boolExisteTicket = false;
        
        if ($intRecibo){
            
            $stmt ="select * from TICKETS where DT_NUMERO  = '{$intRecibo}' "  ;  
            $query = ibase_prepare($stmt);  
            $v_query = ibase_execute($query);  
            $v_reg = ibase_fetch_row($v_query); 
            ibase_free_query($query); 
            if ( is_array($v_reg)  &&  count($v_reg) > 0){  
                $boolExisteTicket = true;
            }
            
        }
        
        $strTextoFinal = $boolExisteTicket ? "Y" : "N";
        
        print $strTextoFinal;
        
    }

    elseif ( $_GET["validaciones"] == "cliente" ){
        
        $strBusqueda = isset($_GET["term"]) ? utf8_decode(trim($_GET["term"])) : "";
        $strBusqueda = strtoupper($strBusqueda);
        
        $arrInfo = array();
        $stmt ="select niu, nombre from CLIENTES where UPPER(nombre) LIKE '%{$strBusqueda}%' "  ;  
        $query = ibase_prepare($stmt);  
        $v_query = ibase_execute($query);  
        while ( $rTMP = ibase_fetch_assoc($v_query) ){
            
            $arrInfo[$rTMP["NIU"]]["niu"] = $rTMP["NIU"];
            $arrInfo[$rTMP["NIU"]]["nombre"] = trim($rTMP["NOMBRE"]);
            
        }
        ibase_free_result($v_query);
        
        $result = array();
        if ( is_array($arrInfo) && ( count($arrInfo) > 0 ) ){
            
            reset($arrInfo);
            while ( $rTMP = each($arrInfo) ){
                
                $arrTMP = array();
                $arrTMP["id"] = utf8_encode($rTMP["key"]);
                $arrTMP["value"] = utf8_encode($rTMP["key"]." - ".$rTMP["value"]["nombre"]);
                                                                                                                                 
                array_push($result, $arrTMP);
                
            }
        }
        
        print json_encode($result);
        
        
    }
    elseif ( $_GET["validaciones"] == "producto" ){
        
        $strBusqueda = isset($_GET["term"]) ? utf8_decode(trim($_GET["term"])) : "";
        $strBusqueda = strtoupper($strBusqueda);
        
        $strFecha = isset($_GET["fecha"]) ? trim($_GET["fecha"]) : "";
        
        $arrInfo = array();
        
        if ( !empty($strFecha) ){
            
            
            $boolFirstTime = true;
            $sinPrecio = 0;
            $stmt = "SELECT PRECIO FROM PRECOMB WHERE DESDE >= '{$strFecha}' AND HASTA <= '{$strFecha}' ORDER BY niu DESC";
            $query = ibase_prepare($stmt);  
            $v_query = ibase_execute($query);  
            while ( $rTMP = ibase_fetch_assoc($v_query) ){

                if ( $boolFirstTime ){
                    $sinPrecio = floatval($rTMP["PRECIO"]);
                }
                
                $boolFirstTime = false;
                
            }
            ibase_free_result($v_query);
            
            
            $stmt ="select PROD_NIU, DESCRIP, CODIGO, EXISTENC, NIU_COMBUSTIBLES, CTRLEXIS, EXISTENCD, EXISTENCQ, MONEDA, TASACOMP from PRODUCTO2 where UPPER(descrip) LIKE '%{$strBusqueda}%' "  ;  
            $query = ibase_prepare($stmt);  
            $v_query = ibase_execute($query);  
            while ( $rTMP = ibase_fetch_assoc($v_query) ){

                $arrInfo[$rTMP["PROD_NIU"]]["id"] = $rTMP["PROD_NIU"];
                $arrInfo[$rTMP["PROD_NIU"]]["nombre"] = trim($rTMP["DESCRIP"]);
                $arrInfo[$rTMP["PROD_NIU"]]["codigo"] = trim($rTMP["CODIGO"]);
                $arrInfo[$rTMP["PROD_NIU"]]["existenc"] = $rTMP["EXISTENC"];
                $arrInfo[$rTMP["PROD_NIU"]]["galones"] = $rTMP["EXISTENC"]; 
                $arrInfo[$rTMP["PROD_NIU"]]["precio"] = $sinPrecio; 
                $arrInfo[$rTMP["PROD_NIU"]]["combustibles"] = $rTMP["NIU_COMBUSTIBLES"];
                $arrInfo[$rTMP["PROD_NIU"]]["ctrlexis"] = $rTMP["CTRLEXIS"];
                $arrInfo[$rTMP["PROD_NIU"]]["existencd"] = $rTMP["EXISTENCD"];
                $arrInfo[$rTMP["PROD_NIU"]]["existencq"] = $rTMP["EXISTENCQ"];
                $arrInfo[$rTMP["PROD_NIU"]]["moneda"] = $rTMP["MONEDA"];
                $arrInfo[$rTMP["PROD_NIU"]]["tasacomp"] = $rTMP["TASACOMP"];

            }
            ibase_free_result($v_query);
            
        }
            
        
        $result = array();
        
        if ( is_array($arrInfo) && ( count($arrInfo) > 0 ) ){
            

            reset($arrInfo);
            while ( $rTMP = each($arrInfo) ){
                

                $strVAlorHidden = $rTMP["key"]." - ".$rTMP["value"]["codigo"]." - ".$rTMP["value"]["nombre"]." - ".$rTMP["value"]["existenc"]." - ".$rTMP["value"]["galones"]." - ".$rTMP["value"]["precio"]." - ".$rTMP["value"]["combustibles"]." - ".$rTMP["value"]["ctrlexis"]." - ".$rTMP["value"]["existencd"]." - ".$rTMP["value"]["existencq"]." - ".$rTMP["value"]["moneda"]." - ".$rTMP["value"]["tasacomp"];

                $arrTMP = array();
                $arrTMP["id"] = utf8_encode($rTMP["key"]);
                $arrTMP["value"] = utf8_encode($rTMP["value"]["nombre"]);
                $arrTMP["valor_hidden"] = utf8_encode($strVAlorHidden);
                $arrTMP["galon"] = utf8_encode($rTMP["value"]["galones"]);

                array_push($result, $arrTMP);

            }
        }
        
        print json_encode($result);
        
        
    }
    elseif ( $_GET["validaciones"] == "aeronave" ){
        
        $strBusqueda = isset($_GET["term"]) ? utf8_decode(trim($_GET["term"])) : "";
        $strBusqueda = strtoupper($strBusqueda);
        
        $arrInfo = array();
        $stmt ="select niu, tipo, matricula from AERONAVES where niu_cliente IS NOT NULL and UPPER(tipo) LIKE '%{$strBusqueda}%' "  ;  
        $query = ibase_prepare($stmt);  
        $v_query = ibase_execute($query);  
        while ( $rTMP = ibase_fetch_assoc($v_query) ){
            
            $arrInfo[$rTMP["NIU"]]["id"] = $rTMP["NIU"];
            $arrInfo[$rTMP["NIU"]]["tipo"] = trim($rTMP["TIPO"]);
            $arrInfo[$rTMP["NIU"]]["matricula"] = trim($rTMP["MATRICULA"]);
            
        }
        ibase_free_result($v_query);
        
        $result = array();
        if ( is_array($arrInfo) && ( count($arrInfo) > 0 ) ){
            
            reset($arrInfo);
            while ( $rTMP = each($arrInfo) ){
                
                $arrTMP = array();
                $arrTMP["id"] = utf8_encode($rTMP["key"]);
                $arrTMP["value"] = utf8_encode($rTMP["value"]["tipo"]);
                $arrTMP["matricula"] = utf8_encode($rTMP["value"]["matricula"]);
                                                                                                                                 
                array_push($result, $arrTMP);
                
            }
        }
        
        print json_encode($result);
        
        
    }
    
    die();
    
}


if ( isset($_POST["hidFormulario"]) ){
     
    $strDtNumero = isset($_POST["recibo_entrega"]) ? trim($_POST["recibo_entrega"]) : "";
    $strFecha = isset($_POST["fecha_despacho"]) ? trim($_POST["fecha_despacho"]) : "";
    
    $strCliente = isset($_POST["hidCliente"]) ? trim($_POST["hidCliente"]) : "";
    $arrExplode = explode(" - ", $strCliente);
    $intNiUCliente = $arrExplode[0];
    $strNombre = $arrExplode[1];
    
    $strTipo = isset($_POST["tipo_aeronave"]) ? trim($_POST["tipo_aeronave"]) :  "";
    $strMatricula = isset($_POST["matricula_aeronave"]) ? trim($_POST["matricula_aeronave"]) :  "";
    
    $strLugarDes = isset($_POST["lugar_despacho"]) ? trim($_POST["lugar_despacho"]) : "";
    $strHoraIni = isset($_POST["hora_inicio_servicio"]) ? trim($_POST["hora_inicio_servicio"]) : "";
    $strHoraFin = isset($_POST["hora_final_servicio"]) ? trim($_POST["hora_final_servicio"]) : "";
    $strDesc = isset($_POST["camion"]) ? trim($_POST["camion"]) : "";
    $strEntrega = $strLugarDes;
    $strDesc = isset($_POST["cantidad_letras"]) ? trim($_POST["cantidad_letras"]) : "";
    $strOwener = "";//USUARIO LOGEADO
    
    reset($_POST);
    while ( $rTMP = each($_POST) ){
        
        $arrExplode = explode("_", $rTMP["key"]);
        
        if ( $arrExplode[0] == "hidproducto" ){
            
            $intCantidad = isset($_POST["galones_{$arrExplode[1]}"]) ? floatval($_POST["galones_{$arrExplode[1]}"]) : 0;
            
            $strProducto = isset($_POST["hidproducto_{$arrExplode[1]}"]) ? trim($_POST["hidproducto_{$arrExplode[1]}"]) : "";
            $arrSplit = explode(" - ", $strProducto);
            
            $strNombreProducto = $arrSplit[2];
            $intProdNiU = $arrSplit[0];
            $sinPCosto = $arrSplit[5];
            $sinTasaCambio = $arrSplit[11];
            $sinValorC = $arrSplit[9];
            $sinPCostOD = $sinPCosto;
            $sinValorCD = $arrSplit[8];
            $intMoneda = $arrSplit[10];
            
            $strEstado = "";//INI
            
            $stmt = "execute procedure grabar_tickets ('{autoincrement}','{$strFecha}','{$strDtNumero}','{$strNombre}','{$intNiUCliente}','{$strNombreProducto}','{$intCantidad}','{$strFecha}','{$strTipo}','{$strMatricula}','{$strLugarDes}','{$strHoraIni}','{$strHoraFin}','{$strCamion}','{$strEntrega}','{$strDesc}','{$strOwener}','{$intProdNiU}','{$sinPCosto}','{$sinTasaCambio}','{$sinValorC}','{$sinPCostOD}','{$strEstado}','{$sinValorCD}','{$intMoneda}')";
            $query = ibase_prepare($stmt);  
            $v_query = ibase_execute($query);  
            
        }
        
        
    }
    
    
}

?>
<!DOCTYPE html>

<html lang"es">
    <script src="view/js/main.js"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <head>
       <title>Formulario</title>
       <meta charset="UTF-8">
        <?php
        load_header();
        ?>
   </head>
  
   <body>
      <form action="formulario.php" method="post">
           <input type="hidden" name="hidFormulario" value="1">
            
          <a href="logout.php" class="alert alert-primary">SALIR</a> 
          <P></P>
          <h2>INGRESO DE DT</h2>
          <input type="number" id="recibo_entrega" name="recibo_entrega" placeholder="Recibo De Entrega" onchange="fntValidacionRecibo();" required>
          <div id="divErrorRecciboEntrega" style="display:none;" class="alert alert-danger">El número de recibo que desea colocar ya está siendo utilizado.</div>
          <P></P>
          <input type="date" name="fecha_despacho" id="fecha_despacho" onchange="fntCambioFecha();" placeholder="Fecha De Despacho" required>
          <input type="text" name="cliente" id="cliente" placeholder="Cliente" onfocus="fntAutoCompleteCliente();" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();" required>
          <input type="hidden" name="hidCliente" id="hidCliente">
          <table id="tbProductos" width="100%">
              <tbody>
                  
              </tbody>
          </table>
          <img src="images/green-plus-sign-md.png" onclick="fntAddProductos();" style="cursor:pointer;" width="20" height="20">
          <p></p>
          <input type="number" name="cantidad" id="cantidad" placeholder="Cantidad" required>
          <input type="text" name="tipo_aeronave" id="tipo_aeronave" onfocus="fntAutoCompleteAeronave();" placeholder="Tipo De Aeronave" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();" required>
          <input type="text" name="matricula_aeronave" id="matricula_aeronave" placeholder="Matricula" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();" required>
          <input type="text" name="lugar_despacho" placeholder="Lugar De Despacho" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();" required>
          <input type="time" name="hora_inicio_servicio" placeholder="Hora Iniciado Servicio" required>
          <input type="time" name="hora_final_servicio" placeholder="Hora Finalizado Servicio" required>
          <input type="number" name="camion" placeholder="Camion" required>
          <input type="mensaje" name="cantidad_letras" placeholder="Cantidad Despachada en Letras" style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();" required>
          <input type="submit" value="ENVIAR" id="boton">
      </form>
      <script>

          function fntValidacionRecibo(){
              
                
              var objReciboEntrega = document.getElementById("recibo_entrega");
              var intRecibo = objReciboEntrega.value*1;
              
              var objdivErrorRecciboEntrega = document.getElementById("divErrorRecciboEntrega");
              objdivErrorRecciboEntrega.style.display = "none";
                
                
              if ( !isNaN(intRecibo) && (intRecibo>0) ){
                                                          
                  $.ajax({
                      
                      url: "formulario.php?validaciones=recibo_entrega&recibo="+intRecibo,
                      async: true,
                      global: false,

                      success: function(data) {
                          
                          if (data == "Y"){
                              objdivErrorRecciboEntrega.style.display = "";
                              objReciboEntrega.value = "";
                          }
                            
                            

                          return false;
                      }
                  });
                    
              }
              else{
                  objdivErrorRecciboEntrega.style.display = "";
                  objReciboEntrega.value = "";
              }
                
              return false;
            }
          
          
          function fntAutoCompleteCliente(){
              
              
              $( "#cliente" ).autocomplete({
                                                                 
                 source: "formulario.php?validaciones=cliente",
                 minLength: 2,
                 select: function( event, ui ) {
                     
                     var objhidCliente = document.getElementById("hidCliente");
                     var objcliente = document.getElementById("cliente");
                     
                     objhidCliente.value = ui.item.value;
                     objcliente.value = ui.item.value;
                     
                 }
             });
              
          }
          
          var intProductos = 1;
          function fntAddProductos(){
              
              var strHtml = "";
                strHtml = "<tr>"+
                              "<td>"+
                                  "<input type=\"text\" name=\"producto_"+intProductos+"\" id=\"producto_"+intProductos+"\" placeholder=\"Producto\" required>"+
                                  "<input type=\"hidden\" name=\"hidproducto_"+intProductos+"\" id=\"hidproducto_"+intProductos+"\">"+
                              "</td>"+
                          "</tr>"+
                          "<tr>"+
                              "<td>"+
                                  "<input type=\"number\" name=\"galones_"+intProductos+"\" id=\"galones_"+intProductos+"\" onchange=\"fntCalculoGalones();\" placeholder=\"Galones\" required>"+
                              "</td>"+
                          "</tr>";

                $("#tbProductos > tbody").append(strHtml);
              
              fntAutoCompleteProducto(intProductos);
              intProductos++;
          }
          
          function fntAutoCompleteProducto(intIndex){
              
              var objFecha = document.getElementById("fecha_despacho");
              var strFecha = objFecha.value;
              
              if ( strFecha != "" ){
                  
                  $( "#producto_"+intIndex ).autocomplete({

                     source: "formulario.php?validaciones=producto&fecha="+strFecha,
                     minLength: 2,
                     select: function( event, ui ) {

                         var objhidCliente = document.getElementById("hidproducto_"+intIndex);
                         var objcliente = document.getElementById("producto_"+intIndex);
                         var objgalon = document.getElementById("galones_"+intIndex);


                         objhidCliente.value = ui.item.valor_hidden;
                         objcliente.value = ui.item.value;
                         objgalon.value = ui.item.galon;

                         fntCalculoGalones();

                     }
                 });
                  
              }
              
                  
              
          }
          
          function fntCambioFecha(){
              $("input[id*='galones_']").each(function(){
                  
                  var arrSplit = $(this).attr("id").split("_");
                  
                  var objgalon = document.getElementById("galones_"+arrSplit[1]);
                  objgalon.value = 0;

                  fntAutoCompleteProducto(arrSplit[1]);

              });
              
              fntCalculoGalones();
          }
          
          function fntCalculoGalones(){
              
              var objcantidad = document.getElementById("cantidad");
              
              var sinTotalGalones = 0;
              
              $("input[id*='galones_']").each(function(){
                  
                  var arrSplit = $(this).attr("id").split("_");

                  var objgalon = document.getElementById("galones_"+arrSplit[1]);
                  var sinGalon = objgalon.value*1;
                  
                  sinTotalGalones += sinGalon;

              });
              
              objcantidad.value = sinTotalGalones;
              
          }
          
          
          
          function fntAutoCompleteAeronave(){
              
              $( "#tipo_aeronave" ).autocomplete({
                                                                 
                 source: "formulario.php?validaciones=aeronave",
                 minLength: 2,
                 select: function( event, ui ) {
                     
                     var objtipoaeronave = document.getElementById("tipo_aeronave");
                     var objmatricula = document.getElementById("matricula_aeronave");
                     
                     objtipoaeronave.value = ui.item.value;
                     objmatricula.value = ui.item.matricula;
                     
                 }
             });
              
          }
          
          fntAddProductos();
          
          
       </script>
   </body>
</html>


