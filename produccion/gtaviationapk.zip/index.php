<?php 
require 'main_app/main.php';
?>


<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>DISCOLSA</title>
        <?php
         load_header();
        ?>
    </head>
    <body>
       
       <h2>DISCOL S.A.</h2>

          <div class="imgcontainer">
            <img src="images/discolsa.jpg" alt="Avatar" class="avatar">
          </div>
        <?php 
        if( isset($_REQUEST['error']) ){
            ?>
            <div class="error">
                <span class="alert alert-danger">Datos de Ingreso no validos, intente de nuevo
                </span>
            </div>
            <?php
        }
        if( isset($_SESSION['usuario']) && $_SESSION['usuario'] != ''  ){
            header('Location:formulario.php');
        }
        ?>       
        <div class="main">
            <form action="login.php" id="formlg" method="post">
                <input type="text" name="usuariolg" placeholder="Usuario" required />
                <input type="password" name="passlg" placeholder="Contraseña" required/>
                <button type="submit" class="botonlg">Iniciar Sesion</button>
            </form>            
        </div>
    </body>
</html>