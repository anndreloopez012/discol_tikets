<?php
/*
    $cons ibase_connect("C:\\sincaf\\sincafd","SYSDBA","bawjdr");
    if(!$con)
    { echo "Acceso Denegado!";
    exit; }

*/
 
function conectar(){ 
    //$host = 'localhost:C:\BDASCII.FDB '; 
    $host = 'C:\\sincaf\\sincafd\SINCAF.FDB'; 
    $username = "SYSDBA"; 
    $password = "bawjdr"; 
    $dbh = ibase_connect( $host, $username, $password ) or die ("Acceso Denegado!"); 
}
?>
